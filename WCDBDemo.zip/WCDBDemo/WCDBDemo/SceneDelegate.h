//
//  SceneDelegate.h
//  WCDBDemo
//
//  Created by 刘少华 on 2020/10/19.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

